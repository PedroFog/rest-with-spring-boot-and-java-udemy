package com.br.com.udemy.springbootaws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestWithSpringBootAndJavaUdemyApplicationTests {

	@Test
	void contextLoads() {
	}

}
