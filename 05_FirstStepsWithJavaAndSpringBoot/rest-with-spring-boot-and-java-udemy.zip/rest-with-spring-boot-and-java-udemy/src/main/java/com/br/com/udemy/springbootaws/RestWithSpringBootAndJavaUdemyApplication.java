package com.br.com.udemy.springbootaws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestWithSpringBootAndJavaUdemyApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestWithSpringBootAndJavaUdemyApplication.class, args);
	}

}
